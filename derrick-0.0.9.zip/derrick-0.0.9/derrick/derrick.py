#!/usr/bin/env python
# coding=utf-8

from __future__ import absolute_import, division, print_function
from derrick.core.derrick import Derrick


def main():
    dk = Derrick()
    dk.run()


if __name__ == "__main__":
    main()
