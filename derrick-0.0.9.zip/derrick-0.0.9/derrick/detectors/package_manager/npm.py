#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import, division, print_function
from derrick.core.detector import Detector

class NpmDetector(Detector):
    def execute(self, *args, **kwargs):
        pass 